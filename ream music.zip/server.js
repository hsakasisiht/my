const express = require('express');
const { PrismaClient } = require('@prisma/client');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const prisma = new PrismaClient();
const port = process.env.PORT || 3001;

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });

// Middleware
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// API Routes
app.get('/api/songs', async (req, res) => {
  try {
    const { query } = req.query;
    const songs = await prisma.song.findMany({
      where: query
        ? {
            OR: [
              { title: { contains: query } },
              { artist: { contains: query } },
              { album: { contains: query } },
            ],
          }
        : undefined,
      orderBy: { createdAt: 'desc' },
    });
    res.json(songs);
  } catch (error) {
    console.error('Error fetching songs:', error);
    res.status(500).json({ error: 'Error fetching songs' });
  }
});

app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    const { title, artist, album } = req.body;
    const file = req.file;

    if (!file || !title || !artist) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const song = await prisma.song.create({
      data: {
        title,
        artist,
        album,
        filePath: `/uploads/${file.filename}`,
        duration: 0,
      },
    });

    res.json(song);
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Error uploading file' });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
}); 